/*
 * Win7Taskbar - Core nativo - implementazione dell'ABI extern "C"
 * Copyright (c) 2026 Win7Taskbar contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#define W7T_BUILDING_DLL 1

#include "Common.h"
#include <shellapi.h>
#include "SehGuard.h"
#include "WindowManager.h"
#include "TrayService.h"
#include "PinnedApps.h"
#include "AppBarService.h"
#include "ShellMenu.h"
#include "TrayOverflowWindow.h"
#include "AppSearchWindow.h"
#include "PropertiesDialog.h"
#include "FlyoutLauncher.h"
#include "AudioService.h"
#include "JumpListWindow.h"     /* v2.38 */
#include "BatteryFlyout.h"      /* v2.38 */
#include <thread>
#include <atomic>
#include <psapi.h>

using namespace w7t;

namespace {

inline HWND ToHwnd(uint64_t value) {
    return reinterpret_cast<HWND>(static_cast<uintptr_t>(value));
}

} /* namespace */

extern "C" W7T_API int32_t W7T_CALL W7T_ShowContextMenu(int32_t x, int32_t y,
                                                        int32_t bottomEdge,
                                                        const wchar_t* items) {
    return ShellMenu::ShowContextMenu(x, y, bottomEdge != 0, items);
}


extern "C" W7T_API int32_t W7T_CALL W7T_ShowContextMenuEx(int32_t x, int32_t y,
                                                          int32_t bottomEdge,
                                                          const wchar_t* items,
                                                          int32_t anchorAtCursor) {
    return ShellMenu::ShowContextMenuEx(x, y, bottomEdge != 0, items,
                                        anchorAtCursor != 0);
}

extern "C" W7T_API int32_t W7T_CALL W7T_TrayImportExplorerIcons(void) {
    return TrayService::Instance().ImportExplorerIcons();
}

/* ------------------------------------------------------------------ */
/*  Ciclo di vita                                                      */
/* ------------------------------------------------------------------ */

extern "C" W7T_API int32_t W7T_CALL W7T_Initialize(W7T_EventCallback cb) {
    CoreState& state = CoreState::Instance();
    if (state.IsInitialized()) {
        return W7T_ERR_ALREADY_INIT;
    }

    state.SetCallback(cb);
    WindowManager::Instance().Start();
    w7t::PinnedApps::Instance().Start();
    state.SetInitialized(true);
    return W7T_OK;
}

extern "C" W7T_API void W7T_CALL W7T_Shutdown(void) {
    w7t::PinnedApps::Instance().Stop();
    CoreState& state = CoreState::Instance();
    if (!state.IsInitialized()) {
        return;
    }

    TrayService::Instance().Stop();
    WindowManager::Instance().Stop();

    /* Ripristina sempre la shell prima di sparire. */
    AppBarService& appBar = AppBarService::Instance();
    appBar.Unregister(nullptr);
    if (appBar.IsNativeTaskbarHidden()) {
        appBar.SetNativeTaskbarHidden(false);
    }

    state.SetCallback(nullptr);
    state.SetInitialized(false);
}

extern "C" W7T_API uint32_t W7T_CALL W7T_GetVersion(void) {
    /* 0xMMmmpppp */
    return 0x00010000u;
}

extern "C" W7T_API int32_t W7T_CALL W7T_PumpEvents(int32_t maxEvents) {
    CoreState& state = CoreState::Instance();
    W7T_EventCallback cb = state.Callback();
    if (cb == nullptr) {
        return 0;
    }

    std::vector<QueuedEvent> events = state.DrainEvents(maxEvents);
    for (const QueuedEvent& e : events) {
        cb(e.evt, e.a, e.b);
    }
    return static_cast<int32_t>(events.size());
}

/* ------------------------------------------------------------------ */
/*  Superbar                                                           */
/* ------------------------------------------------------------------ */

extern "C" W7T_API int32_t W7T_CALL W7T_RefreshWindows(void) {
    return WindowManager::Instance().Refresh();
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetWindowCount(void) {
    return WindowManager::Instance().GetCount();
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetWindows(W7T_WindowInfo* buffer, int32_t capacity) {
    return WindowManager::Instance().CopyTo(buffer, capacity);
}

/* v2.25: Pinned Application Model - sorgente autoritativa dei pin. */
/* v2.26: icona di un elemento pinnato SENZA freccia di collegamento:
 * stesso resolver della ricerca (Common.cpp). L'HICON e' di proprieta'
 * del chiamante (DestroyIcon). */
extern "C" W7T_API HICON W7T_CALL W7T_GetLinkIcon(const wchar_t* lnk,
                                                  const wchar_t* target,
                                                  int32_t large) {
    W7T_SEH_TRY {
        return ResolveAppIcon(lnk, target, large != 0);
    } W7T_SEH_CATCH {} W7T_SEH_END
    return nullptr;
}

/* v2.28: avvio di un elemento (lnk/exe) via ShellExecute con retry:
 * ogni tanto la shell risponde SE_ERR_* transitori (DDE occupato,
 * antivirus che blocca l'istante dell'apertura) e il programma "non si
 * apre al primo colpo". Tre tentativi a 200 ms coprono il caso senza
 * cambiare altro. */
extern "C" W7T_API int32_t W7T_CALL W7T_ShellOpen(const wchar_t* path) {
    if (path == nullptr || path[0] == 0) return 0;
    for (int attempt = 0; attempt < 3; ++attempt) {
        HINSTANCE r = nullptr;
        W7T_SEH_TRY {
            r = ShellExecuteW(nullptr, L"open", path, nullptr, nullptr,
                              SW_SHOWNORMAL);
        } W7T_SEH_CATCH { r = nullptr; } W7T_SEH_END
        if (reinterpret_cast<intptr_t>(r) > 32) {
            return 1;
        }
        wchar_t line[400];
        _snwprintf_s(line, _TRUNCATE,
                     L"shell-open: tentativo %d fallito (%p) su %.300s",
                     attempt + 1, (void*)r, path);
        AppendCoreLog(line);
        if (attempt < 2) Sleep(200);
    }
    return 0;
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetPinnedCount(void) {
    return w7t::PinnedApps::Instance().GetCount();
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetPinnedApps(W7T_PinnedInfo* buffer, int32_t capacity) {
    return w7t::PinnedApps::Instance().CopyTo(buffer, capacity);
}

extern "C" W7T_API void W7T_CALL W7T_PinnedRefresh(void) {
    w7t::PinnedApps::Instance().Refresh();
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetWindowInfo(uint64_t hwnd, W7T_WindowInfo* out) {
    if (out == nullptr) {
        return W7T_ERR_INVALID_ARG;
    }
    return WindowManager::Instance().GetInfo(ToHwnd(hwnd), out) ? W7T_OK : W7T_ERR_NOT_FOUND;
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetWindowIconBitmap(uint64_t hwnd, int32_t desiredSize,
                                                            int32_t* width, int32_t* height,
                                                            uint8_t* pixels, int32_t pixelsBytes) {
    return WindowManager::Instance().GetIconBitmap(ToHwnd(hwnd), desiredSize,
                                                   width, height, pixels, pixelsBytes);
}

extern "C" W7T_API int32_t W7T_CALL W7T_ExecuteWindowCommand(uint64_t hwnd, int32_t cmd) {
    return WindowManager::Instance().ExecuteCommand(ToHwnd(hwnd), cmd);
}

extern "C" W7T_API int32_t W7T_CALL W7T_MinimizeGroup(const wchar_t* appId) {
    if (appId == nullptr) {
        return W7T_ERR_INVALID_ARG;
    }
    return WindowManager::Instance().MinimizeGroup(std::wstring(appId));
}

extern "C" W7T_API int32_t W7T_CALL W7T_CloseGroup(const wchar_t* appId) {
    if (appId == nullptr) {
        return W7T_ERR_INVALID_ARG;
    }
    return WindowManager::Instance().CloseGroup(std::wstring(appId));
}

extern "C" W7T_API int32_t W7T_CALL W7T_IsFullScreenAppActive(void) {
    return WindowManager::Instance().IsFullScreenAppActive() ? 1 : 0;
}

/* ------------------------------------------------------------------ */
/*  System tray                                                        */
/* ------------------------------------------------------------------ */

extern "C" W7T_API int32_t W7T_CALL W7T_TrayStart(void) {
    return TrayService::Instance().Start();
}

extern "C" W7T_API void W7T_CALL W7T_TrayStop(void) {
    TrayService::Instance().Stop();
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetTrayIconCount(void) {
    return TrayService::Instance().GetCount();
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetTrayIcons(W7T_TrayIconInfo* buffer, int32_t capacity) {
    return TrayService::Instance().CopyTo(buffer, capacity);
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetTrayIconBitmap(uint64_t ownerHwnd, uint32_t uid,
                                                          int32_t* width, int32_t* height,
                                                          uint8_t* pixels, int32_t pixelsBytes) {
    return TrayService::Instance().GetIconBitmap(ownerHwnd, uid, width, height,
                                                 pixels, pixelsBytes);
}

extern "C" W7T_API int32_t W7T_CALL W7T_SendTrayIconClick(uint64_t ownerHwnd, uint32_t uid,
                                                          int32_t clickType, int32_t x, int32_t y) {
    return TrayService::Instance().SendClick(ownerHwnd, uid, clickType, x, y);
}

extern "C" W7T_API int32_t W7T_CALL W7T_SetTrayIconPinned(uint64_t ownerHwnd, uint32_t uid,
                                                          int32_t pinned) {
    return TrayService::Instance().SetPinned(ownerHwnd, uid, pinned);
}

extern "C" W7T_API int32_t W7T_CALL W7T_TrayMoveIcon(uint64_t sourceHwnd, uint32_t sourceUid,
                                                     uint64_t targetHwnd, uint32_t targetUid,
                                                     int32_t insertAfter) {
    return TrayService::Instance().MoveIcon(sourceHwnd, sourceUid,
                                            targetHwnd, targetUid, insertAfter);
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetLastBalloon(W7T_BalloonInfo* out) {
    if (out == nullptr) {
        return W7T_ERR_INVALID_ARG;
    }
    return TrayService::Instance().GetLastBalloon(out) ? W7T_OK : W7T_ERR_NOT_FOUND;
}

/* ------------------------------------------------------------------ */
/*  AppBar                                                             */
/* ------------------------------------------------------------------ */

extern "C" W7T_API int32_t W7T_CALL W7T_AppBarRegister(uint64_t hwnd, int32_t edge, int32_t sizePx) {
    return AppBarService::Instance().Register(ToHwnd(hwnd), edge, sizePx);
}

extern "C" W7T_API int32_t W7T_CALL W7T_AppBarSetPos(uint64_t hwnd, int32_t edge, int32_t sizePx,
                                                     int32_t* outLeft, int32_t* outTop,
                                                     int32_t* outRight, int32_t* outBottom) {
    RECT rect = {};
    const int32_t result = AppBarService::Instance().SetPos(ToHwnd(hwnd), edge, sizePx, &rect);
    if (result != W7T_OK) {
        return result;
    }
    if (outLeft)   *outLeft   = rect.left;
    if (outTop)    *outTop    = rect.top;
    if (outRight)  *outRight  = rect.right;
    if (outBottom) *outBottom = rect.bottom;
    return W7T_OK;
}

extern "C" W7T_API int32_t W7T_CALL W7T_AppBarUnregister(uint64_t hwnd) {
    return AppBarService::Instance().Unregister(ToHwnd(hwnd));
}

extern "C" W7T_API int32_t W7T_CALL W7T_SetNativeTaskbarHidden(int32_t hidden) {
    return AppBarService::Instance().SetNativeTaskbarHidden(hidden != 0);
}

extern "C" W7T_API int32_t W7T_CALL W7T_IsNativeTaskbarHidden(void) {
    return AppBarService::Instance().IsNativeTaskbarHidden() ? 1 : 0;
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetPrimaryWorkArea(int32_t* left, int32_t* top,
                                                           int32_t* right, int32_t* bottom) {
    RECT rect = {};
    const int32_t result = AppBarService::GetPrimaryWorkArea(&rect);
    if (result != W7T_OK) {
        return result;
    }
    if (left)   *left   = rect.left;
    if (top)    *top    = rect.top;
    if (right)  *right  = rect.right;
    if (bottom) *bottom = rect.bottom;
    return W7T_OK;
}

/* ------------------------------------------------------------------ */
/*  Shell                                                              */
/* ------------------------------------------------------------------ */

namespace {

/* Mostra/minimizza tutto come il clic su Aero Peek in Windows 7.
 *
 * Il WM_COMMAND 0x1FE alla tray di Explorer era un id interno di Windows 7:
 * sulle build successive Explorer lo ignora o lo interpreta diversamente,
 * e il clic restava senza effetto. La via documentata e stabile da Windows 7
 * a Windows 11 e' IShellDispatch4::ToggleDesktop dell'oggetto
 * "Shell.Application"; se COM non risponde, Win+D fa esattamente la stessa
 * cosa (e ripristina al secondo colpo, come l'originale). */
bool ToggleDesktopViaShell() {
    CLSID clsid = {};
    if (FAILED(CLSIDFromProgID(L"Shell.Application", &clsid))) {
        return false;
    }

    IDispatch* dispatch = nullptr;
    if (FAILED(CoCreateInstance(clsid, nullptr, CLSCTX_LOCAL_SERVER,
                                IID_IDispatch, reinterpret_cast<void**>(&dispatch)))
        || dispatch == nullptr) {
        return false;
    }

    DISPID dispid = 0;
    OLECHAR* name = const_cast<OLECHAR*>(L"ToggleDesktop");
    const HRESULT found = dispatch->GetIDsOfNames(IID_NULL, &name, 1,
                                                  LOCALE_USER_DEFAULT, &dispid);
    if (FAILED(found)) {
        dispatch->Release();
        return false;
    }

    DISPPARAMS empty = {};
    const HRESULT hr = dispatch->Invoke(dispid, IID_NULL, LOCALE_USER_DEFAULT,
                                        DISPATCH_METHOD, &empty, nullptr,
                                        nullptr, nullptr);
    dispatch->Release();
    return SUCCEEDED(hr);
}

void ToggleDesktopViaKeyboard() {
    INPUT inputs[4] = {};
    inputs[0].type       = INPUT_KEYBOARD;
    inputs[0].ki.wVk     = VK_LWIN;
    inputs[1].type       = INPUT_KEYBOARD;
    inputs[1].ki.wVk     = 'D';
    inputs[2].type       = INPUT_KEYBOARD;
    inputs[2].ki.wVk     = 'D';
    inputs[2].ki.dwFlags = KEYEVENTF_KEYUP;
    inputs[3].type       = INPUT_KEYBOARD;
    inputs[3].ki.wVk     = VK_LWIN;
    inputs[3].ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(4, inputs, sizeof(INPUT));
}

} /* namespace */

extern "C" W7T_API int32_t W7T_CALL W7T_ToggleShowDesktop(void) {
    if (ToggleDesktopViaShell()) {
        return W7T_OK;
    }
    ToggleDesktopViaKeyboard();
    return W7T_OK;
}

/* v2.32: ripiego per l'apertura di Start quando il tap del tasto
 * Windows non arriva (hook di Windhawk/mod che filtrano i tasti
 * iniettati, UIPI con foreground elevato). Ispirato al meccanismo
 * storico di Open-Shell/StartIsBack: WM_SYSCOMMAND con SC_TASKLIST
 * mandato DIRETTAMENTE alla Shell_TrayWnd di Explorer (stessa
 * integrita', niente iniezione di input) + broadcast di sicurezza. */
extern "C" W7T_API int32_t W7T_CALL W7T_OpenStartFallback(void) {
    const bool wasHidden = AppBarService::Instance().IsNativeTaskbarHidden();

    HWND tray = FindWindowW(L"Shell_TrayWnd", nullptr);
    if (tray != nullptr) {
        PostMessageW(tray, WM_SYSCOMMAND, SC_TASKLIST, 0);
    }
    SendMessageTimeoutW(HWND_BROADCAST, WM_SYSCOMMAND, SC_TASKLIST, 0,
                        SMTO_ABORTIFHUNG, 300, nullptr);

    if (wasHidden) {
        std::thread([]() {
            for (int i = 0; i < 20; ++i) {
                Sleep(25);
                AppBarService::Instance().ReassertNativeTaskbarHidden();
            }
        }).detach();
    }
    return W7T_OK;
}

extern "C" W7T_API int32_t W7T_CALL W7T_ShowStartMenu(void) {
    /* Il menu Start si apre simulando il tasto Windows: non esiste un'API
     * pubblica per aprirlo.
     *
     * PROBLEMA: quando Explorer riceve questo tasto rimette in mostra la
     * propria taskbar, che avevamo nascosto. Il risultato e' che si vedono
     * due barre sovrapposte.
     *
     * Windows 7 non aveva il problema perche' la barra ERA quella di
     * Explorer. Qui dobbiamo rinascondere la sua subito dopo: il menu Start
     * resta aperto e visibile, perche' e' una finestra separata dalla
     * taskbar (Windows.UI.Core.CoreWindow / Start su Win10-11). */
    const bool wasHidden = AppBarService::Instance().IsNativeTaskbarHidden();

    INPUT inputs[2] = {};
    inputs[0].type = INPUT_KEYBOARD;
    inputs[0].ki.wVk = VK_LWIN;
    inputs[1].type = INPUT_KEYBOARD;
    inputs[1].ki.wVk = VK_LWIN;
    inputs[1].ki.dwFlags = KEYEVENTF_KEYUP;
    const UINT injected = SendInput(2, inputs, sizeof(INPUT));

    /* v2.30: con un'app in primo piano a integrita' maggiore (UIPI) o con
     * hook che filtrano i tasti iniettati (es. Windhawk aperto), il tap
     * del tasto Windows puo' non arrivare. Ripiego documentato della
     * shell: WM_SYSCOMMAND/SC_TASKLIST in broadcast apre il menu Start
     * senza iniezione di input. */
    if (injected == 0) {
        SendMessageTimeoutW(HWND_BROADCAST, WM_SYSCOMMAND, SC_TASKLIST, 0,
                            SMTO_ABORTIFHUNG, 300, nullptr);
    }

    if (wasHidden) {
        /* Explorer rimostra la barra in modo asincrono, mentre elabora il
         * tasto: un solo tentativo immediato arriverebbe troppo presto.
         * Ripetiamo per un breve periodo su un thread separato, cosi' da
         * non bloccare il chiamante (che e' il thread della UI). */
        std::thread([]() {
            /* v2.30: se il tap non ha aperto il menu (hook/UX che lo
             * filtrano), dopo ~600 ms si tenta il broadcast SC_TASKLIST. */
            Sleep(600);
            {
                bool startVisible = false;
                for (const wchar_t* clsName :
                     { L"DV2ControlHost", L"StartMenuExperienceHost" }) {
                    HWND h = FindWindowW(clsName, nullptr);
                    if (h != nullptr && IsWindowVisible(h)) {
                        startVisible = true;
                        break;
                    }
                }
                if (!startVisible) {
                    HWND x = FindWindowW(L"XamlExplorerHostIslandWindow",
                                         nullptr);
                    while (x != nullptr) {
                        if (IsWindowVisible(x)) {
                            wchar_t t[4]{};
                            if (GetWindowTextW(x, t, 4) == 0) {
                                startVisible = true;
                                break;
                            }
                        }
                        x = FindWindowExW(nullptr, x,
                                          L"XamlExplorerHostIslandWindow",
                                          nullptr);
                    }
                }
                if (!startVisible) {
                    SendMessageTimeoutW(HWND_BROADCAST, WM_SYSCOMMAND,
                                        SC_TASKLIST, 0, SMTO_ABORTIFHUNG,
                                        300, nullptr);
                }
            }
            for (int i = 0; i < 20; ++i) {
                Sleep(25);
                AppBarService::Instance().ReassertNativeTaskbarHidden();
            }
        }).detach();
    }

    return W7T_OK;
}

extern "C" W7T_API int32_t W7T_CALL W7T_GetVolume(int32_t* level, int32_t* muted) {
    return AudioService::GetVolume(level, muted);
}

extern "C" W7T_API int32_t W7T_CALL W7T_SetVolume(int32_t level) {
    return AudioService::SetVolume(level);
}

extern "C" W7T_API int32_t W7T_CALL W7T_SetVolumeMuted(int32_t muted) {
    return AudioService::SetMuted(muted != 0);
}

extern "C" W7T_API int32_t W7T_CALL W7T_ShowClockFlyout(uint64_t taskbarHwnd) {
    return FlyoutLauncher::ShowClockFlyout(ToHwnd(taskbarHwnd));
}

extern "C" W7T_API int32_t W7T_CALL W7T_ShowVolumeFlyout(uint64_t taskbarHwnd) {
    return FlyoutLauncher::ShowVolumeFlyout(ToHwnd(taskbarHwnd));
}

/* ------------------------------------------------------------------ */
/*  Riquadri immersivi: rete, orologio, batteria, volume              */
/*                                                                    */
/*  Un solo export per tutti e quattro. La sequenza di invocazione e' */
/*  adattata da ExplorerPatcher (ImmersiveFlyouts.c di valinet,       */
/*  GPL-2.0-or-later); i dettagli sono in native/src/ImmersiveFlyouts.h */
/* ------------------------------------------------------------------ */

extern "C" W7T_API int32_t W7T_CALL W7T_InvokeFlyout(uint64_t taskbarHwnd,
                                                     int32_t kind,
                                                     int32_t action) {
    /* I valori arrivano dal managed layer: vanno validati prima di
     * trasformarli in enum, altrimenti un intero fuori scala diventerebbe
     * un FlyoutKind inesistente e la switch dentro il modulo non
     * restituirebbe nulla di sensato. */
    switch (kind) {
    case W7T_FLYOUT_NETWORK:
    case W7T_FLYOUT_CLOCK:
    case W7T_FLYOUT_BATTERY:
    case W7T_FLYOUT_SOUND:
        break;
    default:
        return W7T_ERR_INVALID_ARG;
    }

    if (action != W7T_FLYOUT_SHOW && action != W7T_FLYOUT_HIDE) {
        return W7T_ERR_INVALID_ARG;
    }

    return FlyoutLauncher::InvokeFlyout(static_cast<FlyoutKind>(kind),
                                        static_cast<FlyoutAction>(action),
                                        ToHwnd(taskbarHwnd));
}

extern "C" W7T_API int32_t W7T_CALL W7T_ShowVolumeMixer(void) {
    return FlyoutLauncher::ShowVolumeMixer();
}

extern "C" W7T_API int32_t W7T_CALL W7T_SetIconRect(uint64_t ownerHwnd,
                                                    uint32_t uid,
                                                    int32_t left, int32_t top,
                                                    int32_t right, int32_t bottom) {
    RECT rect = { left, top, right, bottom };
    TrayService::Instance().SetIconRect(ownerHwnd, uid, rect);
    return W7T_OK;
}

extern "C" W7T_API int32_t W7T_CALL W7T_SetShellRects(int32_t barLeft, int32_t barTop,
                                                      int32_t barRight, int32_t barBottom,
                                                      int32_t notifyLeft, int32_t notifyTop,
                                                      int32_t notifyRight, int32_t notifyBottom) {
    RECT bar    = { barLeft, barTop, barRight, barBottom };
    RECT notify = { notifyLeft, notifyTop, notifyRight, notifyBottom };
    TrayService::Instance().SetShellRects(bar, notify);
    return W7T_OK;
}

extern "C" W7T_API int32_t W7T_CALL W7T_SetChevronRect(int32_t left, int32_t top,
                                                       int32_t right, int32_t bottom) {
    RECT rect = { left, top, right, bottom };
    TrayService::Instance().SetChevronRect(rect);
    return W7T_OK;
}

extern "C" W7T_API int32_t W7T_CALL W7T_ReanchorFlyouts(void) {
    TrayService::Instance().ReanchorFlyouts();
    return W7T_OK;
}

extern "C" W7T_API int32_t W7T_CALL W7T_ReassertNativeTaskbarHidden(void) {
    AppBarService::Instance().ReassertNativeTaskbarHidden();
    return W7T_OK;
}

extern "C" W7T_API int32_t W7T_CALL W7T_ShowTaskManager(void) {
    SHELLEXECUTEINFOW info = {};
    info.cbSize = sizeof(info);
    info.lpVerb = L"open";
    info.lpFile = L"taskmgr.exe";
    info.nShow  = SW_SHOW;
    info.fMask  = SEE_MASK_NOASYNC;
    return ShellExecuteExW(&info) ? W7T_OK : W7T_ERR_NOT_FOUND;
}

/* v2.1: link "Personalizza..." del riquadro di overflow.
 *
 * Apre la pagina NATIVA di Windows per la scelta delle icone dell'area di
 * notifica passando alla shell il namespace
 *   shell:::{05D7B0F4-2121-4EFF-BF6B-ED3F69B894D9}
 * (CLSID della voce "Icone dell'area di notifica"). E' lo stesso
 * meccanismo che usa Explorer quando si apre quella pagina dal Pannello di
 * controllo: su Windows 7 compare l'applet classica, su Windows 10/11 il
 * sistema reindirizza alla pagina Impostazioni equivalente. Non viene
 * creata NESSUNA finestra sostitutiva: si lascia fare alla shell.
 *
 * Tre tentativi in ordine, perche' il modo in cui la shell accetta il
 * namespace dipende dalla build:
 *   1) ShellExecuteExW sul namespace shell:::{...} (il percorso diretto);
 *   2) explorer.exe che riceve il namespace come argomento (il percorso
 *      che usa l'utente quando lo digita in Esegui);
 *   3) rundll32 shell32.dll,Options_RunDLL non esiste piu' da Vista: non
 *      si forza altro, si lascia al frontend l'ultimo ripiego.
 * Ogni tentativo registra l'esito in log-core.txt per la diagnostica. */
extern "C" W7T_API int32_t W7T_CALL W7T_OpenNotificationIconsSettings(void) {
    /* v2.2: come primo tentativo il percorso completo del Pannello di
     * controllo, nello stesso formato usato dal mod Windhawk "Aero Tray"
     * di aubymori (riferimento riconosciuto nei crediti del progetto). */
    static const wchar_t* const kControlPanelPath =
        L"shell:::{26EE0668-A00A-44D7-9371-BEB064C98683}\\0\\"
        L"::{05D7B0F4-2121-4EFF-BF6B-ED3F69B894D9}";
    static const wchar_t* const kNamespace =
        L"shell:::{05D7B0F4-2121-4EFF-BF6B-ED3F69B894D9}";

    /* v2.54: PRIMO tentativo il namespace shell PURO, quello chiesto
     * esplicitamente dall'utente:
     *     shell:::{05D7B0F4-2121-4EFF-BF6B-ED3F69B894D9}
     * E' l'identificatore della pagina "Icone dell'area di notifica": la
     * shell lo risolve da sola, senza executor intermedi. */
    {
        SHELLEXECUTEINFOW info = {};
        info.cbSize       = sizeof(info);
        info.lpVerb       = L"open";
        info.lpFile       = kNamespace;
        info.nShow        = SW_SHOW;
        info.fMask        = SEE_MASK_NOASYNC | SEE_MASK_FLAG_NO_UI;
        if (ShellExecuteExW(&info)) {
            AppendCoreLog(L"personalizza: aperto via namespace shell (05D7B0F4)");
            return W7T_OK;
        }
        AppendCoreLog(L"personalizza: namespace shell rifiutato, provo explorer.exe");
    }

    /* Tentativo 2: lo stesso namespace passato a explorer.exe (come quando
     * l'utente lo digita in Esegui). */
    {
        SHELLEXECUTEINFOW info = {};
        info.cbSize       = sizeof(info);
        info.lpVerb       = L"open";
        info.lpFile       = L"explorer.exe";
        info.lpParameters = kNamespace;
        info.nShow        = SW_SHOW;
        info.fMask        = SEE_MASK_NOASYNC | SEE_MASK_FLAG_NO_UI;
        if (ShellExecuteExW(&info)) {
            AppendCoreLog(L"personalizza: aperto via explorer.exe col namespace");
            return W7T_OK;
        }
        AppendCoreLog(L"personalizza: explorer.exe non ha aperto il namespace, provo control.exe");
    }

    /* Tentativo 3: l'applet classica via control.exe col nome canonico
     * (quello che usa il Pannello di controllo stesso; su Win10 apre la
     * pagina classica, su Win11 il sistema reindirizza a Impostazioni). */
    {
        SHELLEXECUTEINFOW info = {};
        info.cbSize       = sizeof(info);
        info.lpVerb       = L"open";
        info.lpFile       = L"control.exe";
        info.lpParameters = L"/name Microsoft.NotificationAreaIcons";
        info.nShow        = SW_SHOW;
        info.fMask        = SEE_MASK_NOASYNC;
        if (ShellExecuteExW(&info)) {
            AppendCoreLog(L"personalizza: aperto via control.exe /name Microsoft.NotificationAreaIcons");
            return W7T_OK;
        }
        AppendCoreLog(L"personalizza: control.exe non partito, provo percorso Pannello");
    }

    /* Tentativo 2: percorso completo del Pannello di controllo. */
    {
        SHELLEXECUTEINFOW info = {};
        info.cbSize = sizeof(info);
        info.lpVerb = L"open";
        info.lpFile = kControlPanelPath;
        info.nShow  = SW_SHOW;
        info.fMask  = SEE_MASK_NOASYNC | SEE_MASK_FLAG_NO_UI;
        if (ShellExecuteExW(&info)) {
            AppendCoreLog(L"personalizza: pagina Pannello aperta (ShellExecuteEx)");
            return W7T_OK;
        }
        AppendCoreLog(L"personalizza: percorso Pannello rifiutato, provo namespace corto");
    }

    /* Tentativo 3: namespace shell corto. */
    {
        SHELLEXECUTEINFOW info = {};
        info.cbSize = sizeof(info);
        info.lpVerb = L"open";
        info.lpFile = kNamespace;
        info.nShow  = SW_SHOW;
        info.fMask  = SEE_MASK_NOASYNC | SEE_MASK_FLAG_NO_UI;
        if (ShellExecuteExW(&info)) {
            AppendCoreLog(L"personalizza: namespace shell aperto (ShellExecuteEx)");
            return W7T_OK;
        }
        AppendCoreLog(L"personalizza: ShellExecuteEx sul namespace fallito, provo explorer.exe");
    }

    /* Tentativo 4: explorer.exe col namespace come argomento. */
    {
        SHELLEXECUTEINFOW info = {};
        info.cbSize       = sizeof(info);
        info.lpVerb       = L"open";
        info.lpFile       = L"explorer.exe";
        info.lpParameters = kNamespace;
        info.nShow        = SW_SHOW;
        info.fMask        = SEE_MASK_NOASYNC | SEE_MASK_FLAG_NO_UI;
        if (ShellExecuteExW(&info)) {
            AppendCoreLog(L"personalizza: aperto via explorer.exe");
            return W7T_OK;
        }
        AppendCoreLog(L"personalizza: anche explorer.exe ha rifiutato il namespace");
    }

    return W7T_ERR_NOT_FOUND;
}

/* v2.2: riga di log dal lato gestito (diagnostica dei percorsi
 * interattivi - drag&drop, overflow, Personalizza - su Windows vero). */
extern "C" W7T_API void W7T_CALL W7T_Log(const wchar_t* line) {
    if (line != nullptr) {
        AppendCoreLog(line);
    }
}

/* ------------------------------------------------------------------ */
/*  Menu contestuali Win32 nativi                                      */
/* ------------------------------------------------------------------ */

extern "C" W7T_API int32_t W7T_CALL W7T_ShowWindowSystemMenu(uint64_t hwnd, int32_t x,
                                                             int32_t y, int32_t bottomEdge) {
    return ShellMenu::ShowWindowSystemMenu(ToHwnd(hwnd), x, y, bottomEdge != 0);
}

extern "C" W7T_API int32_t W7T_CALL W7T_ShowGroupMenu(uint64_t hwnd, int32_t x, int32_t y,
                                                      int32_t bottomEdge,
                                                      const wchar_t* minimizeText,
                                                      const wchar_t* closeText) {
    return ShellMenu::ShowGroupMenu(ToHwnd(hwnd), x, y, bottomEdge != 0,
                                    minimizeText, closeText);
}

/* ------------------------------------------------------------------ */
/*  DllMain                                                            */
/* ------------------------------------------------------------------ */

extern "C" BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID) {
    switch (reason) {
        case DLL_PROCESS_ATTACH:
            DisableThreadLibraryCalls(instance);
            break;
        case DLL_PROCESS_DETACH:
            /* v2.41: rilascia le bitmap GDI+ del flyout batteria. */
            w7t::BatteryFlyout::Instance().Shutdown();
            break;
        default:
            break;
    }
    return TRUE;
}

/* v2.7: pannello overflow nativo con vetro Aero (fallback: Popup WPF). */
static TrayOverflowWindow g_overflowWindow;

extern "C" W7T_API int32_t W7T_CALL W7T_OverflowInit(uint64_t ownerTaskbar) {
    return g_overflowWindow.Create(GetModuleHandleW(nullptr),
                                   reinterpret_cast<HWND>(ownerTaskbar)) ? 1 : 0;
}

extern "C" W7T_API void W7T_CALL W7T_OverflowShow(int32_t left, int32_t top,
                                                  int32_t right, int32_t bottom) {
    RECT rc{ left, top, right, bottom };
    g_overflowWindow.ShowNear(rc);
}

extern "C" W7T_API void W7T_CALL W7T_OverflowHide(void) {
    g_overflowWindow.Hide();
}

extern "C" W7T_API int32_t W7T_CALL W7T_OverflowIsVisible(void) {
    return g_overflowWindow.IsVisible() ? 1 : 0;
}

/* v3.1: refresh conservativo del pannello (dopo pin/unpin da C#). */
extern "C" W7T_API void W7T_CALL W7T_OverflowRefresh(void) {
    w7t::TrayOverflowWindow::NotifyTrayChanged();
}

extern "C" W7T_API int32_t W7T_CALL W7T_OverflowGetRect(int32_t* left, int32_t* top,
                                                        int32_t* right, int32_t* bottom) {
    HWND h = g_overflowWindow.NativeHandle();
    if (h == nullptr || !IsWindow(h)) return 0;
    RECT rc{};
    if (!GetWindowRect(h, &rc)) return 0;
    if (left) *left = rc.left;
    if (top) *top = rc.top;
    if (right) *right = rc.right;
    if (bottom) *bottom = rc.bottom;
    return 1;
}

/* v3.0: ricerca applicazioni opzionale (si attiva da Proprietà). */
static w7t::AppSearchWindow g_appSearch;

/* v3.3: finestra Proprietà Win32 classica (schede, come la mod di ref). */
static w7t::PropertiesDialog g_properties;

extern "C" W7T_API void W7T_CALL W7T_PropertiesShow(uint64_t ownerTaskbar,
        int32_t lang, int32_t seconds, int32_t nativeFlyout,
        int32_t enableSearch, int32_t netFlyout, int32_t classicVolume,
        int32_t batteryFlyout, int32_t aeroPeek, int32_t toolbarDesktop,
        int32_t toolbarAddress, int32_t toolbarLinks) {
    try {
        g_properties.Show(reinterpret_cast<HWND>(ownerTaskbar), lang,
                          seconds, nativeFlyout, enableSearch, netFlyout,
                          classicVolume, batteryFlyout, aeroPeek,
                          toolbarDesktop, toolbarAddress, toolbarLinks);
    } catch (...) { /* mai propagare */ }
}

extern "C" W7T_API int32_t W7T_CALL W7T_AppSearchInit(uint64_t ownerTaskbar,
        const uint32_t* argbPixels, int32_t iconW, int32_t iconH) {
    return g_appSearch.Create(GetModuleHandleW(nullptr),
                              reinterpret_cast<HWND>(ownerTaskbar),
                              argbPixels, iconW, iconH) ? 1 : 0;
}

extern "C" W7T_API void W7T_CALL W7T_AppSearchShow(int32_t x, int32_t y) {
    g_appSearch.Show(x, y);
}

extern "C" W7T_API void W7T_CALL W7T_AppSearchHide(void) {
    g_appSearch.Hide();
}

/* v2.37 punto 17: il pulsante lente funziona da interruttore: se la
 * ricerca e' gia' aperta, un click la chiude (e viceversa). */
extern "C" W7T_API int32_t W7T_CALL W7T_AppSearchIsVisible(void) {
    return g_appSearch.IsVisible() ? 1 : 0;
}

/* ------------------------------------------------------------------ */
/* v2.38: Jump List stile Windows 7 (click destro sui pulsanti).       */
/* ------------------------------------------------------------------ */
extern "C" W7T_API void W7T_CALL W7T_JumpListShow(
        const RECT* buttonRect, const wchar_t* title,
        const wchar_t* launchPath, const wchar_t* pinnedLnk,
        int32_t isPinned, const uint32_t* iconArgb,
        int32_t iconW, int32_t iconH, int32_t lang) {
    W7T_SEH_TRY {
        if (buttonRect == nullptr) return;
        w7t::JumpListWindow::Instance().Show(
            *buttonRect,
            title ? title : L"",
            launchPath ? launchPath : L"",
            pinnedLnk ? pinnedLnk : L"",
            isPinned == 1,
            iconArgb, iconW, iconH, lang);
    } W7T_SEH_CATCH {} W7T_SEH_END
}

extern "C" W7T_API void W7T_CALL W7T_JumpListHide(void) {
    W7T_SEH_TRY
        w7t::JumpListWindow::Instance().Hide();
    W7T_SEH_CATCH
    W7T_SEH_END
}

/* ------------------------------------------------------------------ */
/* v2.38: flyout batteria ricreato (icone reali ritagliate).           */
/* ------------------------------------------------------------------ */
extern "C" W7T_API void W7T_CALL W7T_BatteryFlyoutShowAt(
        int32_t left, int32_t top, int32_t right, int32_t bottom) {
    W7T_SEH_TRY {
        RECT rc{ left, top, right, bottom };
        w7t::BatteryFlyout::Instance().ShowAt(rc);
    } W7T_SEH_CATCH {} W7T_SEH_END
}

extern "C" W7T_API void W7T_CALL W7T_BatteryFlyoutHide(void) {
    W7T_SEH_TRY
        w7t::BatteryFlyout::Instance().Hide();
    W7T_SEH_CATCH
    W7T_SEH_END
}

extern "C" W7T_API void W7T_CALL W7T_BatteryFlyoutSetLanguage(int32_t lang) {
    W7T_SEH_TRY
        w7t::BatteryFlyout::Instance().SetLanguage(lang);
    W7T_SEH_CATCH
    W7T_SEH_END
}

/* ------------------------------------------------------------------ */
/* v2.36: flyout di rete Windows 7 (porting MIT della mod Windhawk    */
/* "Windows 7 Network Flyout Recreation" v5.0.0).                     */
/* ------------------------------------------------------------------ */
#include "Win7NetworkFlyout.h"
#include <psapi.h>

extern "C" W7T_API int32_t W7T_CALL W7T_NetFlyoutInit(void) {
    int32_t r = 0;
    W7T_SEH_TRY
        r = w7tnet::W7TNetFlyout_InitInternal() ? 1 : 0;
    W7T_SEH_CATCH
    W7T_SEH_END
    return r;
}

extern "C" W7T_API void W7T_CALL W7T_NetFlyoutUninit(void) {
    W7T_SEH_TRY
        w7tnet::W7TNetFlyout_UninitInternal();
    W7T_SEH_CATCH
    W7T_SEH_END
}

extern "C" W7T_API void W7T_CALL W7T_NetFlyoutToggleAt(const RECT* rcIcon) {
    W7T_SEH_TRY
        w7tnet::W7TNetFlyout_SetAnchorRect(rcIcon);
        w7tnet::W7TNetFlyout_Toggle();
    W7T_SEH_CATCH
    W7T_SEH_END
}

/* v2.37 punto 16: lingua del flyout = lingua dell'app (mapping sugli
 * idiomi gia' tradotti dentro la mod). */
extern "C" W7T_API void W7T_CALL W7T_NetFlyoutSetLanguage(int32_t appLanguageIndex) {
    W7T_SEH_TRY
        w7tnet::W7TNetFlyout_SetLanguage(appLanguageIndex);
    W7T_SEH_CATCH
    W7T_SEH_END
}

/* v2.36/v2.38: modulo (DLL) che possiede la finestra proprietaria di
 * un'icona tray: pnidui.dll = rete, SndVolSSO.dll = volume, stobject.dll
 * = batteria (tutte dentro explorer.exe). La verifica cross-process con
 * psapi vive in Common.cpp (OwnerModuleIs), condivisa col TrayService. */
extern "C" W7T_API int32_t W7T_CALL W7T_IsNetworkTrayOwner(uint64_t ownerHwnd) {
    W7T_SEH_TRY {
        return w7t::OwnerModuleIs(reinterpret_cast<HWND>(
            static_cast<uintptr_t>(ownerHwnd)), L"pnidui.dll") ? 1 : 0;
    } W7T_SEH_CATCH {} W7T_SEH_END
    return 0;
}

/* v2.38: il managed chiede se l'icona tray appartiene a un modulo di
 * sistema (volume/batteria) per decidere i flyout ricreati. */
extern "C" W7T_API int32_t W7T_CALL W7T_TrayOwnerModuleMatch(
        uint64_t ownerHwnd, const wchar_t* moduleName) {
    W7T_SEH_TRY {
        if (moduleName == nullptr) return 0;
        return w7t::OwnerModuleIs(reinterpret_cast<HWND>(
            static_cast<uintptr_t>(ownerHwnd)), moduleName) ? 1 : 0;
    } W7T_SEH_CATCH {} W7T_SEH_END
    return 0;
}

/* v2.40: il flag -f di SndVol non e' affidabile su tutte le build (su
 * alcune il riquadro parte comunque in alto a sinistra). Dopo il lancio,
 * un thread breve cerca la finestra top-level di SndVol.exe e la sposta
 * SOPRA l'icona che l'ha generata, usando le coordinate schermo passate
 * dal managed. Best-effort: se non la trova entro ~1,5 s rinuncia senza
 * toccare nulla. Mai crashare. */
namespace {
bool WindowIsSndVol(HWND h) {
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    if (pid == 0) return false;
    HANDLE hp = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (hp == nullptr) return false;
    wchar_t path[MAX_PATH]{};
    DWORD len = MAX_PATH;
    const bool ok = QueryFullProcessImageNameW(hp, 0, path, &len) != 0;
    CloseHandle(hp);
    if (!ok) return false;
    const wchar_t* name = wcsrchr(path, L'\\');
    name = name ? name + 1 : path;
    return _wcsicmp(name, L"SndVol.exe") == 0;
}
/* v2.44: il flyout di SndVol avviato con -f e' TRANSIENTE: se non riceve
 * MAI il focus si chiude da solo dopo ~2 s (era il difetto segnalato: il
 * riquadro del volume spariva dopo due secondi). Una sola chiamata a
 * SetForegroundWindow non basta, perche' il sistema la RIFIUTA quando il
 * processo chiamante non e' gia' in primo piano (foreground lock). Qui si
 * insiste, con le stesse due tecniche dei progetti open source:
 *  - tap del tasto Alt per sbloccare il foreground-lock (come
 *    WindowManager::ForegroundUnlock, usato per le finestre minimizzate);
 *  - AttachThreadInput sul thread del riquadro, che consente il cambio di
 *    primo piano anche a un processo non attivo. */
void ForceFlyoutForeground(HWND h) {
    if (h == nullptr || !IsWindow(h)) {
        return;
    }
    if (GetForegroundWindow() == h) {
        return;   /* gia' in primo piano: niente da fare */
    }

    /* Primo tentativo, quello pulito: il clic che ha aperto il riquadro e'
     * arrivato al NOSTRO processo, quindi di norma il sistema ci lascia
     * portare in primo piano la finestra che abbiamo appena avviato. */
    SetForegroundWindow(h);
    if (GetForegroundWindow() == h) {
        return;
    }

    /* Ripiego: il sistema ha RIFIUTATO il cambio di primo piano (locks
     * SPI_GETFOREGROUNDLOCKTIMEOUT). Le due tecniche dei progetti open
     * source, le stesse che questa mod usa gia' per attivare le finestre
     * dei pulsanti della Superbar: tap del tasto Alt con SendInput, che fa
     * risultare il nostro processo come "ultimo input", e AttachThreadInput
     * sul thread del riquadro. */
    INPUT unlock[2] = {};
    unlock[0].type = INPUT_KEYBOARD;
    unlock[0].ki.wVk = VK_MENU;
    unlock[1].type = INPUT_KEYBOARD;
    unlock[1].ki.wVk = VK_MENU;
    unlock[1].ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(2, unlock, sizeof(INPUT));

    const DWORD targetThread = GetWindowThreadProcessId(h, nullptr);
    const DWORD thisThread = GetCurrentThreadId();
    bool attached = false;
    if (targetThread != 0 && targetThread != thisThread) {
        attached = AttachThreadInput(thisThread, targetThread, TRUE) != FALSE;
    }
    SetForegroundWindow(h);
    BringWindowToTop(h);
    if (attached) {
        AttachThreadInput(thisThread, targetThread, FALSE);
    }
}

/* v2.44: guardiano del riquadro volume.
 *
 * La finestra dei ~2 s e' quella in cui SndVol si autodistrugge quando non
 * ha mai ricevuto il focus: qui si insiste a darglielo finche' non l'ha
 * ottenuto (o finche' non e' finita la finestra critica). Il primo
 * SetForegroundWindow viene spesso RIFIUTATO dal sistema, perche' il
 * processo della barra non e' in primo piano quando parte questo thread
 * (il clic che ha aperto il riquadro e' arrivato a una finestra
 * WS_EX_NOACTIVATE, che non prende il focus): senza questa insistenza il
 * riquadro spariva comunque dopo due secondi.
 *
 * Dopo la finestra critica il guardiano NON tocca piu' nulla: se il focus
 * lo prende un'altra applicazione, il riquadro si chiude, esattamente come
 * in Windows 7 (e un clic sulla nostra barra lo chiude subito via
 * W7T_CloseClassicVolume).
 *
 * Il ciclo si interrompe subito se il riquadro non esiste piu', cosi' non
 * c'e' nessuna attesa residua quando l'utente l'ha gia' chiuso. Nessun
 * blocco sul thread chiamante: gira nel thread dedicato lanciato da
 * W7T_LaunchClassicVolume. */
void KeepSndVolFlyoutAlive(HWND h) {
    /* ~2,5 s complessivi, un tentativo ogni 350 ms. */
    for (int i = 0; i < 7; ++i) {
        if (!IsWindow(h) || !IsWindowVisible(h)) {
            return;   /* chiuso: il guardiano ha finito */
        }
        if (GetForegroundWindow() == h) {
            /* Ha il focus: da qui in poi si tiene aperto da solo, come in
             * Windows 7, finche' l'utente non clicca altrove. */
            AppendCoreLog(L"volume: flyout in primo piano, resta aperto");
            return;
        }
        ForceFlyoutForeground(h);
        Sleep(350);
    }
    AppendCoreLog(L"volume: il flyout non ha ottenuto il primo piano "
                  L"(restera' il comportamento transiente di SndVol: "
                  L"si chiude da solo dopo ~2 s)");
}

void RepositionSndVolAbove(int x, int y) {
    /* v2.55: RIPRISTINATO il comportamento che funzionava.
     *
     * La v2.54 aveva provato a intercettare il riquadro prima che fosse
     * visibile (polling ogni 5 ms, nessuna attesa iniziale, nascondi ->
     * sposta -> mostra). Su Windows vero il risultato e' stato PEGGIORE: il
     * riquadro finiva in alto a sinistra, perche' SndVol completa la
     * propria inizializzazione DOPO di noi e riporta la finestra nella sua
     * posizione di default. Intercettarlo troppo presto, e soprattutto
     * nascondere/rimostrare la finestra, interferisce con quella sequenza.
     *
     * Qui si torna all'ordine precedente: si aspetta che il riquadro sia
     * DAVVERO visibile (SndVol ha finito di posizionarsi), poi lo si sposta
     * sopra l'icona, senza mai nasconderlo. */
    for (int i = 0; i < 30; ++i) {
        Sleep(50);
        struct Ctx { HWND found; };
        Ctx ctx{ nullptr };
        EnumWindows([](HWND h, LPARAM lp) -> BOOL {
            Ctx* c = reinterpret_cast<Ctx*>(lp);
            if (IsWindowVisible(h) && WindowIsSndVol(h)) {
                c->found = h;
                return FALSE;
            }
            return TRUE;
        }, reinterpret_cast<LPARAM>(&ctx));
        if (ctx.found != nullptr) {
            RECT rc{};
            GetWindowRect(ctx.found, &rc);
            const int w = rc.right - rc.left;
            const int hgt = rc.bottom - rc.top;
            /* v2.42: il riquadro ancora sopra l'icona fluttuando appena:
             * 1,5% della propria altezza sopra il bordo superiore
             * dell'icona (richiesta utente), non il distacco overflow.
             * v2.43: richiesto di alzarlo ancora di un 1,5%: il distacco
             * passa da 1,5% a 3% dell'altezza del riquadro, cosi' il
             * flyout stile Windows 7 fluttua appena piu' in alto sopra
             * l'icona di volume.
             * v2.45: ultimo ritocco richiesto, +1,02%: distacco 4,02%
             * (30 -> 40,2 su 1000) per centrare la posizione voluta. */
            int gap = (hgt * 402) / 10000;
            if (gap < 2) gap = 2;
            SetWindowPos(ctx.found, HWND_TOPMOST,
                         x - w / 2, y - hgt - gap, 0, 0,
                         SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER);
            /* v2.42: il flyout -f e' transiente se non riceve mai il
             * focus (si chiude da solo dopo ~2 s). Attivandolo resta
             * aperto finche' l'utente non clicca altrove (e un clic
             * sulla nostra barra lo chiude via W7T_CloseClassicVolume).
             * v2.44: l'attivazione viene ora RIPETUTA per qualche secondo
             * dal guardiano, perche' il primo tentativo puo' essere
             * rifiutato dal sistema e il riquadro sparire comunque. */
            ForceFlyoutForeground(ctx.found);
            KeepSndVolFlyoutAlive(ctx.found);
            return;
        }
    }
}
} /* namespace */

/* v2.38 punto 1: mixer volume classico. SndVol.exe esiste in System32
 * su Win10/11; -f accetta le coordinate impaccate in un DWORD
 * (LOWORD=x, HIWORD=y, come documentato dal comportamento del binario
 * e dal mod windhawk "legacy-sound-flyout", MIT). CreateProcessW senza
 * attese: fire-and-forget; se il binario manca, ritorna 0 e il managed
 * ricade sul flyout attuale. */
extern "C" W7T_API int32_t W7T_CALL W7T_LaunchClassicVolume(
        int32_t x, int32_t y) {
    W7T_SEH_TRY {
        static std::atomic<ULONGLONG> s_last{ 0 };
        const ULONGLONG now = GetTickCount64();
        ULONGLONG last = s_last.load();
        if (now - last < 400) return 1;   /* debounce: gia' lanciato */
        s_last.store(now);
        wchar_t sys32[MAX_PATH]{};
        GetSystemDirectoryW(sys32, MAX_PATH);
        wchar_t cmd[1024]{};
        const DWORD encoded = static_cast<DWORD>(MAKELONG(
            static_cast<SHORT>(x), static_cast<SHORT>(y)));
        wsprintfW(cmd, L"\"%s\\SndVol.exe\" -f %u", sys32, encoded);
        STARTUPINFOW si{};
        si.cb = sizeof(si);
        si.dwFlags = STARTF_FORCEOFFFEEDBACK;
        PROCESS_INFORMATION pi{};
        if (CreateProcessW(nullptr, cmd, nullptr, nullptr, FALSE, 0,
                           nullptr, nullptr, &si, &pi)) {
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            /* v2.40: ancora il riquadro sopra l'icona (best-effort). */
            std::thread([x, y]() { RepositionSndVolAbove(x, y); }).detach();
            return 1;
        }
        return 0;
    } W7T_SEH_CATCH {} W7T_SEH_END
    return 0;
}

/* v2.41: chiude il mixer classico (SndVol) quando un clic sulla nostra
 * barra deve chiudere i riquadri aperti, come per orologio/rete. */
extern "C" W7T_API void W7T_CALL W7T_CloseClassicVolume(void) {
    W7T_SEH_TRY {
        EnumWindows([](HWND h, LPARAM) -> BOOL {
            if (IsWindowVisible(h) && WindowIsSndVol(h))
                PostMessageW(h, WM_CLOSE, 0, 0);
            return TRUE;
        }, 0);
    } W7T_SEH_CATCH {} W7T_SEH_END
}
